#!/bin/bash

#DeclaraciÃ³n de les variables de ip's dels tres ordenasdors:

ord1="192.168.28.110"
ord2="192.168.28.104"
ord3="192.168.28.219"

#DeclaraciÃ³n de las variables para la contraseÃ±a y el usario de manera automatica:

pass1='test2021'
user1='test'
pass='Vicent2002'
user='vicent'


#Pasar el archius per scp a les tres maquines:

	#Pc1
	sshpass -p $pass1 scp img1.html $user1@$ord1:/tmp
	sshpass -p $pass1 scp 1pc.sh $user1@$ord1:/tmp
	sshpass -p $pass1 scp sainz3.png $user1@$ord1:/tmp
	sshpass -p $pass1 scp negro.html $user1@$ord1:/tmp
	sshpass -p $pass1 scp negro.sh $user1@$ord1:/tmp
	sshpass -p $pass1 scp n.jpeg $user1@$ord1:/tmp
	sshpass -p $pass1 scp n.html $user1@$ord1:/tmp
	sshpass -p $pass1 scp n.sh $user1@$ord1:/tmp
	#Pc2
	sshpass -p $pass scp img2.html $user@$ord2:/tmp
	sshpass -p $pass scp 2pc.sh $user@$ord2:/tmp
	sshpass -p $pass scp sainz2.png $user@$ord2:/tmp
	sshpass -p $pass scp negro.html $user@$ord2:/tmp
	sshpass -p $pass scp negro.sh $user@$ord2:/tmp
	sshpass -p $pass scp i.jpeg $user@$ord2:/tmp
	sshpass -p $pass scp i.sh $user@$ord2:/tmp
	sshpass -p $pass scp i.html $user@$ord2:/tmp
	#Pc3
	sshpass -p $pass1 scp img3.html $user1@$ord3:/tmp
	sshpass -p $pass1 scp 3pc.sh $user1@$ord3:/tmp
	sshpass -p $pass1 scp sainz1.png $user1@$ord3:/tmp
	sshpass -p $pass1 scp negro.html $user1@$ord3:/tmp
	sshpass -p $pass1 scp negro.sh $user1@$ord3:/tmp
	sshpass -p $pass1 scp w.jpeg $user1@$ord3:/tmp
	sshpass -p $pass1 scp w.html $user1@$ord3:/tmp
	sshpass -p $pass1 scp w.sh $user1@$ord3:/tmp


#Conectarse al ordenador 3 y per a ejecutar:

sshpass -p $pass1 ssh $user1@$ord3 bash /tmp/3pc.sh &
sleep 2

#Conectarse al ordenador 2 per a ejecutar el scrpt 2pc.sh, i conectarse al ordenador 3 per a ejecutar negro.sh:

sshpass -p $pass ssh $user@$ord2 bash /tmp/2pc.sh & 
sshpass -p $pass1 ssh $user1@$ord3 bash /tmp/negro.sh
sleep 2

#Conectarse al ordenador 1 per a ejecutar el script 1pc.sh, i conectarse al ordenador 2 per a ejecutar negro.sh:

sshpass -p $pass1 ssh $user1@$ord1 bash /tmp/1pc.sh &
sshpass -p $pass ssh $user@$ord2 bash /tmp/negro.sh
sleep 2

#Conectarse al ordenador 1 per a ejecutar el script negro.sh

sshpass -p $pass1 ssh $user1@$ord1 bash /tmp/negro.sh
sleep 2

#Conectarse al ordenador 3 per a mostrar w.sh, al ordenador 2 per a mostrar i.sh, i a l'ordenador 1 per a mostrar n.sh

sshpass -p $pass1 ssh $user1@$ord3 bash /tmp/w.sh
sshpass -p $pass ssh $user@$ord2 bash /tmp/i.sh
sshpass -p $pass1 ssh $user1@$ord1 bash /tmp/n.sh

