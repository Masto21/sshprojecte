#/bin/bash
export DISPLAY=':0'

firefox --kiosk /tmp/img1.html
